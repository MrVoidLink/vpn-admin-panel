function AdminInfo() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold">Admin Info</h2>
      {/* محتوای صفحه اینجاست */}
    </div>
  );
}

export default AdminInfo;
